#loading an image
import matplotlib.pyplot as plt
# example of loading an image with the Keras API
from keras.preprocessing.image import load_img

# load the image
img_path = '/content/drive/MyDrive/2026_Teaching/ST1/Week_6_TutLab/insect.PNG''
img = load_img(img_path)

# report details about the image
print(type(img))
print(img.format)
print(img.mode)
print(img.size)

# show the image using matplotlib
plt.imshow(img)
plt.axis('off') # Turn off axis labels
plt.show()




