
import matplotlib.pyplot as plt
from keras.preprocessing.image import load_img

img = load_img(img_path)
plt.imshow(img)
plt.show()
